# Organ and Blood Donation Management System

A comprehensive, web-based academic project built to connect organ donors, blood donors, patients, hospitals, and administrators seamlessly. The system aims to manage organ and blood donations efficiently using an intelligent priority-based matching algorithm.

## 🚀 Features & Modules

### 1. Admin Module
- Secure supervision dashboard.
- Manage all Donor and Patient registrations.
- System-wide monitoring of life-saving medical requests.
- Hospital network verification.

### 2. Donor Module
- Dedicated donor dashboard and profile configuration.
- Specify exact Organ or Blood type available for donation.
- Toggle Availability status.
- **Intelligent Matching**: Donors see a dynamically ranked list of compatible patients based on priority scores.
- Instantly pledge donations to waiting patients.

### 3. Patient Module
- Submit immediate Blood supply requests (Processed and broadcasted automatically).
- Submit complete Organ transplant requests (Requires Hospital verification).
- Track the lifecycle and status of placed medical requests.

### 4. Hospital Module
- Manage institutional capabilities and verify licenses.
- **Verification Authority**: Hospitals must physically verify Organ Transplant requests before they enter the system's matching pool.
- Manage completed surgeries and transplant updates.

## 🧠 Intelligent Priority-Based Matching Algorithm
The core algorithm calculates a distinct numerical **Priority Score** for patients actively requesting blood or organs. Donors matching the criteria see these patients sorted by this score:

`Score = (Urgency Level × 10) - (Distance_KM × 0.1) + (Wait time in days × 2)`

1. **Medical Urgency**: Critical urgency levels (1 to 5) are highly prioritized.
2. **Location Proximity**: Uses the Haversine formula on registered coordinates to locate the geographically closest recipient.
3. **Wait Duration**: Patients waiting the longest automatically gain priority over time.

## 💻 Technology Stack
- **Frontend**: HTML5, CSS3 (Vanilla / Custom Variables), JavaScript
- **Backend Core**: PHP 8+
- **Database Architecture**: MySQL (PDO Extensions)
- **Local Server Environment**: Apache / XAMPP

---

## 🛠️ Step-by-Step Local Setup & Installation

Follow these instructions to run the application on your local machine using XAMPP.

### Step 1: Environment Setup
1. **Download and Install XAMPP**: If you haven't already, install XAMPP for your Operating System.
2. **Locate `htdocs`**: Find your XAMPP installation directory and locate the `htdocs` folder.
   - *Windows*: `C:\xampp\htdocs\`
   - *Mac*: `/Applications/XAMPP/xamppfiles/htdocs/`
3. **Move the Project**: Copy this entire `OrganBloodDonationSystem` folder into your `htdocs` directory.

### Step 2: Boot Services
1. Open the **XAMPP Control Panel**.
2. Click **Start** explicitly for both **Apache** and **MySQL** modules.

### Step 3: Database Setup via phpMyAdmin
1. Open your web browser and navigate to exactly: `http://localhost/phpmyadmin/`
2. In the left sidebar, click **New** to create a new database.
3. Name the database **`organ_blood_donation`** and click **Create**.
4. Select the newly created `organ_blood_donation` database.
5. Click on the **Import** tab at the top.
6. Click **Choose File** and locate `OrganBloodDonationSystem/sql/schema.sql`. Click **Import / Go** at the bottom.
   - *This generates all the required tables and relational links.*
7. Click the **Import** tab again.
8. Click **Choose File** and locate `OrganBloodDonationSystem/sql/seed.sql`. Click **Import / Go**.
   - *This injects the sample test users, hospitals, and requests into the system.*

### Step 4: Run the Application
1. Open your web browser.
2. Navigate to: `http://localhost/OrganBloodDonationSystem/`
3. You should now see the "Give the Gift of Life" landing page layout!

---

## 🔑 Default Test Accounts
The `seed.sql` script creates pre-configured accounts so you can test the system's workflow immediately.

| Role | Username | Password | Notes |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin_test` | `password` | Has universal dashboard access. |
| **Hospital** | `metro_hospital` | `password` | Verified Network Hospital. |
| **Donor** | `donor_jane` | `password` | Universal Donor (O-) and Kidney available. |
| **Patient** | `patient_mark` | `password` | Has pending Organ and Blood requests. |

### How to Test the Workflow:
1. Log in as `patient_mark` to see the pending medical requests.
2. Log in as `metro_hospital` to verify the pending Organ request.
3. Log in as `donor_jane`, go to "Matching Requests," and see the algorithm rank your matches! Click "Pledge" to make a donation.
4. Log back in as `metro_hospital` to mark the matched surgery as "Completed".

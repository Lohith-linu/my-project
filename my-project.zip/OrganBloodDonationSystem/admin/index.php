<?php
// admin/index.php
require_once "../includes/auth.php";
requireRole(['Admin']);

// Fetch main stats
$stats = [
    'donors' => $pdo->query("SELECT COUNT(*) FROM donors")->fetchColumn(),
    'patients' => $pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn(),
    'blood_req' => $pdo->query("SELECT COUNT(*) FROM blood_requests")->fetchColumn(),
    'organ_req' => $pdo->query("SELECT COUNT(*) FROM organ_requests")->fetchColumn(),
    'hospitals' => $pdo->query("SELECT COUNT(*) FROM hospitals")->fetchColumn()
];

// Fetch recently registered users
$recent_users = $pdo->query("SELECT id, username, role, created_at FROM users ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

require_once "../includes/header.php";
?>

<div class="dashboard-container">
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="index.php" class="active">Dashboard Main</a></li>
            <li><a href="users.php">Manage Users</a></li>
            <li><a href="requests.php">Manage Requests</a></li>
            <li><a href="hospitals.php">Verify Hospitals</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Admin Overview Dashboard</h2>
        
        <div class="grid-cards">
            <div class="stat-card">
                <h3><?php echo $stats['donors']; ?></h3>
                <p>Registered Donors</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['patients']; ?></h3>
                <p>Registered Patients</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['hospitals']; ?></h3>
                <p>Hospitals Network</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['blood_req'] + $stats['organ_req']; ?></h3>
                <p>Total Life Requests</p>
            </div>
        </div>

        <div class="card">
            <h3>Recently Registered Participants</h3>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Username</th>
                            <th>Role Group</th>
                            <th>Join Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($recent_users as $user): ?>
                        <tr>
                            <td>#<?php echo htmlspecialchars($user['id']); ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><span class="status-badge status-approved"><?php echo htmlspecialchars($user['role']); ?></span></td>
                            <td><?php echo htmlspecialchars(date('M d, Y', strtotime($user['created_at']))); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($recent_users)): ?>
                        <tr><td colspan="4">No users found. Waiting for registrations.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once "../includes/footer.php"; ?>

<?php
// admin/hospitals.php
require_once "../includes/auth.php";
requireRole(['Admin']);

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['verify_id'])) {
    $verify_id = $_POST['verify_id'];
    $stmt = $pdo->prepare("UPDATE hospitals SET verified = TRUE WHERE id = ?");
    $stmt->execute([$verify_id]);
}

// Ensure the ID exists in users table first. Using exact column references.
// Note: If some entries are disconnected, they won't show. LEFT JOIN might be better.
$hospitals = $pdo->query("SELECT h.id, h.hospital_name, h.license_no, h.location_coords, h.verified, u.username 
                          FROM hospitals h 
                          JOIN users u ON h.user_id = u.id 
                          ORDER BY h.id DESC")->fetchAll(PDO::FETCH_ASSOC);

require_once "../includes/header.php";
?>
<div class="dashboard-container">
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="index.php">Dashboard Main</a></li>
            <li><a href="users.php">Manage Users</a></li>
            <li><a href="requests.php">Manage Requests</a></li>
            <li><a href="hospitals.php" class="active">Verify Hospitals</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Hospital Network Verification</h2>

        <div class="card">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Hospital ID</th>
                            <th>Institution Name</th>
                            <th>Admin Account</th>
                            <th>Official License No.</th>
                            <th>Network Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($hospitals as $h): ?>
                        <tr>
                            <td>#<?php echo htmlspecialchars($h['id']); ?></td>
                            <td><?php echo htmlspecialchars($h['hospital_name']); ?></td>
                            <td><?php echo htmlspecialchars($h['username']); ?></td>
                            <td><?php echo htmlspecialchars($h['license_no']); ?></td>
                            <td>
                                <?php if($h['verified']): ?>
                                    <span class="status-badge status-approved">Verified Network</span>
                                <?php else: ?>
                                    <span class="status-badge status-pending">Pending Audit</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(!$h['verified']): ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="verify_id" value="<?php echo $h['id']; ?>">
                                    <button type="submit" class="btn btn-teal" style="padding: 4px 10px; font-size: 0.85rem;" onclick="return confirm('You are authorizing this hospital to manage transplant requests. Continue?');">Approve Access</button>
                                </form>
                                <?php else: ?>
                                    <span style="color: #2e7d32; font-weight: bold;">✓ Live</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($hospitals)): ?>
                            <tr><td colspan="6">No hospitals have registered yet.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once "../includes/footer.php"; ?>

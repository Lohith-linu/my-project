<?php
// admin/requests.php
require_once "../includes/auth.php";
requireRole(['Admin']);

$blood_reqs = $pdo->query("SELECT b.id, p.full_name, b.blood_group_needed, b.volume_ml, b.priority, b.status, b.request_date, b.distance 
                           FROM blood_requests b JOIN patients p ON b.patient_id = p.id")->fetchAll(PDO::FETCH_ASSOC);

// Calculate score for each blood request dynamically
$bg_highest = [];
foreach($blood_reqs as &$r) {
    $urgencyScore = 40;
    if($r['priority'] == 'Critical') $urgencyScore = 100;
    elseif($r['priority'] == 'Urgent') $urgencyScore = 70;
    
    // calculate waiting days
    $days = floor((time() - strtotime($r['request_date'])) / 86400);
    $r['waitingDays'] = max(0, $days);
    
    $waitingScore = $r['waitingDays'] * 2;
    $dist = isset($r['distance']) ? (int)$r['distance'] : 0;
    $r['distance'] = $dist;
    
    $distanceScore = 100 - $dist;
    
    $r['priority_score'] = $urgencyScore + $waitingScore + $distanceScore;
    
    // find max per blood group for auto-approval
    $bg = $r['blood_group_needed'];
    if($r['status'] !== 'Fulfilled') {
        if(!isset($bg_highest[$bg]) || $r['priority_score'] > $bg_highest[$bg]['score']) {
            $bg_highest[$bg] = ['id' => $r['id'], 'score' => $r['priority_score']];
        }
    }
}
unset($r);

// Auto-approval logic 
foreach($blood_reqs as &$r) {
    if($r['status'] == 'Fulfilled') continue; // Do not touch historically fulfilled transactions
    
    $bg = $r['blood_group_needed'];
    $newStatus = ($bg_highest[$bg]['id'] == $r['id']) ? 'Approved' : 'Pending';
    
    // Save state back to DB and instance
    if($r['status'] !== $newStatus) {
        $pdo->prepare("UPDATE blood_requests SET status = ?, priority_score = ? WHERE id = ?")->execute([$newStatus, $r['priority_score'], $r['id']]);
        $r['status'] = $newStatus;
    } else {
        $pdo->prepare("UPDATE blood_requests SET priority_score = ? WHERE id = ?")->execute([$r['priority_score'], $r['id']]);
    }
}
unset($r);

// Sort array for display: Blood group ASC, then PriorityScore DESC
usort($blood_reqs, function($a, $b) {
    if($a['blood_group_needed'] == $b['blood_group_needed']) {
        if ($b['priority_score'] == $a['priority_score']) {
            return strtotime($a['request_date']) <=> strtotime($b['request_date']);
        }
        return $b['priority_score'] <=> $a['priority_score'];
    }
    return strcmp($a['blood_group_needed'], $b['blood_group_needed']);
});


$organ_reqs = $pdo->query("SELECT o.id, p.full_name, o.organ_needed, o.priority, o.priority_score, o.status, o.request_date, h.hospital_name 
                           FROM organ_requests o 
                           JOIN patients p ON o.patient_id = p.id 
                           LEFT JOIN hospitals h ON o.hospital_id = h.id 
                           ORDER BY o.request_date DESC")->fetchAll(PDO::FETCH_ASSOC);

require_once "../includes/header.php";
?>
<div class="dashboard-container">
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="index.php">Dashboard Main</a></li>
            <li><a href="users.php">Manage Users</a></li>
            <li><a href="requests.php" class="active">Manage Requests</a></li>
            <li><a href="hospitals.php">Verify Hospitals</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Global Platform Requests Monitor</h2>

        <div class="card" style="max-width: 100%; overflow-x: auto;">
            <h3 style="color: var(--primary-red);"><span style="font-size: 1.5rem;">🩸</span> Blood Component Requests Matrix</h3>
            <p style="font-size: 0.9rem; color: #555;">Displaying top-ranked dynamic allocation list per Blood Group. The intelligent scoring system exclusively sets the topmost match to 'Approved', queuing the rest.</p>
            <div class="table-responsive">
                <table style="table-layout: auto;">
                    <thead>
                        <tr>
                            <th>Req ID</th>
                            <th>Patient Name</th>
                            <th>Blood Group</th>
                            <th>Volume</th>
                            <th>Priority</th>
                            <th>Waiting Days</th>
                            <th>Distance (km)</th>
                            <th>Priority Score</th>
                            <th>Status (Rank)</th>
                            <th>Request Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $current_bg = '';
                        foreach($blood_reqs as $idx => $r): 
                            $isTop = false;
                            if($current_bg != $r['blood_group_needed'] && $r['status'] !== 'Fulfilled' && $r['status'] == 'Approved') {
                                $current_bg = $r['blood_group_needed'];
                                $isTop = true;
                            }
                        ?>
                        <tr style="<?php if($isTop) echo 'background-color:#fff3cd; border-left:4px solid #ffc107;'; ?>">
                            <td>#B-<?php echo htmlspecialchars($r['id']); ?></td>
                            <td><?php echo htmlspecialchars($r['full_name']); ?></td>
                            <td><strong style="color:var(--primary-red);"><?php echo htmlspecialchars($r['blood_group_needed']); ?></strong></td>
                            <td><?php echo htmlspecialchars($r['volume_ml']); ?> ml</td>
                            <td>
                                <?php 
                                    $p_color = '#28a745';
                                    if($r['priority'] == 'Critical') $p_color = '#dc3545';
                                    elseif($r['priority'] == 'Urgent') $p_color = '#ffc107';
                                ?>
                                <span style="color:<?php echo $p_color; ?>;font-weight:bold;"><?php echo htmlspecialchars($r['priority']); ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($r['waitingDays']); ?> d</td>
                            <td><?php echo htmlspecialchars($r['distance']); ?> km</td>
                            <td><span style="background:#007bff;color:white;padding:3px 8px;border-radius:10px;font-weight:bold;"><?php echo round($r['priority_score']); ?></span></td>
                            <td>
                                <?php 
                                    $class = "status-pending";
                                    if($r['status'] == 'Approved') $class = "status-approved";
                                    if($r['status'] == 'Fulfilled') $class = "status-completed";
                                ?>
                                <span class="status-badge <?php echo $class; ?>"><?php echo htmlspecialchars($r['status']); ?></span>
                                <?php if($isTop) echo '<small style="color:#d39e00;font-weight:bold;display:block;">#1 Target</small>'; ?>
                            </td>
                            <td><?php echo htmlspecialchars(date('M d, Y', strtotime($r['request_date']))); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($blood_reqs)) echo "<tr><td colspan='10'>No active blood requests monitored.</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card" style="margin-top: 20px;">
            <h3 style="color: var(--primary-teal);"><span style="font-size: 1.5rem;">🫀</span> Organ Transplant Requests</h3>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Reg ID</th>
                            <th>Patient Identity</th>
                            <th>Required Organ</th>
                            <th>Verifying Hospital</th>
                            <th>Priority</th>
                            <th>Base Score</th>
                            <th>Match Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($organ_reqs as $r): ?>
                        <tr>
                            <td>#O-<?php echo htmlspecialchars($r['id']); ?></td>
                            <td><?php echo htmlspecialchars($r['full_name']); ?></td>
                            <td><strong style="color:var(--primary-teal);"><?php echo htmlspecialchars($r['organ_needed']); ?></strong></td>
                            <td><?php echo $r['hospital_name'] ? htmlspecialchars($r['hospital_name']) : '<i style="color:gray;">Pending assignment</i>'; ?></td>
                            <td>
                                <?php 
                                    $p_color = '#28a745';
                                    if($r['priority'] == 'Critical') $p_color = '#dc3545';
                                    elseif($r['priority'] == 'Urgent') $p_color = '#ffc107';
                                ?>
                                <span style="color:<?php echo $p_color; ?>;font-weight:bold;"><?php echo htmlspecialchars($r['priority']); ?></span>
                            </td>
                            <td><span style="background:#007bff;color:white;padding:3px 8px;border-radius:10px;font-weight:bold;"><?php echo round($r['priority_score'] ?? 0,1); ?></span></td>
                            <td>
                                <?php 
                                    $class = "status-pending";
                                    if($r['status'] == 'Verified') $class = "status-verified";
                                    if($r['status'] == 'Matched') $class = "status-matched";
                                    if($r['status'] == 'Completed') $class = "status-completed";
                                ?>
                                <span class="status-badge <?php echo $class; ?>"><?php echo htmlspecialchars($r['status']); ?></span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($organ_reqs)) echo "<tr><td colspan='7'>No active organ requests monitored.</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>
<?php require_once "../includes/footer.php"; ?>

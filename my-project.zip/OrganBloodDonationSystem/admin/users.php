<?php
// admin/users.php
require_once "../includes/auth.php";
requireRole(['Admin']);

// Handle deletion logic
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_id'])) {
    $del_id = $_POST['delete_id'];
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role != 'Admin'");
    $stmt->execute([$del_id]);
    // Uses ON DELETE CASCADE to cleanup related donors/patients records
}

$users = $pdo->query("SELECT id, username, role, created_at FROM users ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

require_once "../includes/header.php";
?>
<div class="dashboard-container">
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="index.php">Dashboard Main</a></li>
            <li><a href="users.php" class="active">Manage Users</a></li>
            <li><a href="requests.php">Manage Requests</a></li>
            <li><a href="hospitals.php">Verify Hospitals</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>System Users Management</h2>

        <div class="card">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Registered Username</th>
                            <th>Platform Role</th>
                            <th>Registration Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($users as $user): ?>
                        <tr>
                            <td>#<?php echo htmlspecialchars($user['id']); ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><span class="status-badge status-pending"><?php echo htmlspecialchars($user['role']); ?></span></td>
                            <td><?php echo htmlspecialchars(date('M d, Y H:i', strtotime($user['created_at']))); ?></td>
                            <td>
                                <?php if($user['role'] !== 'Admin'): ?>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('WARNING: Are you sure you want to completely delete this user and all associated data?');">
                                    <input type="hidden" name="delete_id" value="<?php echo $user['id']; ?>">
                                    <button type="submit" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.85rem; border-color: red; color: red;">Erase User</button>
                                </form>
                                <?php else: ?>
                                    <span style="color: gray; font-size: 0.85rem;">Root / System</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once "../includes/footer.php"; ?>

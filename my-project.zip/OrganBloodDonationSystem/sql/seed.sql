-- sql/seed.sql
-- Sample Seed Data for Testing Purposes
USE organ_blood_donation;

-- 1. Insert Core Platform Admin
INSERT INTO users (id, username, password_hash, role) VALUES 
(1, 'admin_test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin'); -- Password is 'password'

-- 2. Insert Hospital
INSERT INTO users (id, username, password_hash, role) VALUES 
(2, 'metro_hospital', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Hospital');
INSERT INTO hospitals (user_id, hospital_name, license_no, location_coords, verified) VALUES 
(2, 'Metropolitan Central Hospital', 'LIC-MCH-993', '40.7128,-74.0060', 1);

-- 3. Insert Super Donor
INSERT INTO users (id, username, password_hash, role) VALUES 
(3, 'donor_jane', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Donor');
INSERT INTO donors (user_id, full_name, blood_group, organ_offered, contact_info, location_coords, is_available) VALUES 
(3, 'Jane Doe', 'O-', 'Kidney', '555-010-999', '40.7306,-73.9352', 1);

-- 4. Insert Patient Requester
INSERT INTO users (id, username, password_hash, role) VALUES 
(4, 'patient_mark', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Patient');
INSERT INTO patients (user_id, full_name, blood_group, contact_info, location_coords, age) VALUES 
(4, 'Mark Smith', 'A+', 'mark@email.com', '40.7589,-73.9851', 30);

-- 5. Pre-fill a Blood Request
INSERT INTO blood_requests (patient_id, blood_group_needed, volume_ml, priority, priority_score, status) VALUES 
(1, 'O-', 500, 'Urgent', 70, 'Approved');

-- 6. Pre-fill an Organ Request
INSERT INTO organ_requests (patient_id, organ_needed, priority, priority_score, status, hospital_id) VALUES 
(1, 'Kidney', 'Critical', 100, 'Pending', NULL);

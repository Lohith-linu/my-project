-- sql/schema.sql

CREATE DATABASE IF NOT EXISTS organ_blood_donation;
USE organ_blood_donation;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'Donor', 'Patient', 'Hospital') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS donors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    blood_group VARCHAR(5) NOT NULL,
    organ_offered VARCHAR(50) DEFAULT 'None',
    contact_info VARCHAR(20) NOT NULL,
    location_coords VARCHAR(100) NOT NULL, -- Format: "Lat,Long"
    is_available BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    blood_group VARCHAR(5) NOT NULL,
    contact_info VARCHAR(20) NOT NULL,
    location_coords VARCHAR(100) NOT NULL,
    age INT DEFAULT 30,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS hospitals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    hospital_name VARCHAR(150) NOT NULL,
    license_no VARCHAR(100) NOT NULL UNIQUE,
    location_coords VARCHAR(100) NOT NULL,
    verified BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS blood_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    blood_group_needed VARCHAR(5) NOT NULL,
    volume_ml INT NOT NULL,
    priority ENUM('Normal', 'Urgent', 'Critical') NOT NULL,
    priority_score FLOAT DEFAULT 0,
    status ENUM('Pending', 'Approved', 'Fulfilled') DEFAULT 'Pending',
    request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS organ_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    organ_needed VARCHAR(50) NOT NULL,
    priority ENUM('Normal', 'Urgent', 'Critical') NOT NULL,
    priority_score FLOAT DEFAULT 0,
    status ENUM('Pending', 'Verified', 'Matched', 'Completed') DEFAULT 'Pending',
    hospital_id INT NULL, -- which hospital verified and is handling it
    request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS donations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT NOT NULL,
    request_id INT NOT NULL,
    donation_type ENUM('Blood', 'Organ') NOT NULL,
    status ENUM('Matched', 'Completed') DEFAULT 'Matched',
    match_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE
);

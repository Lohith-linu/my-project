<?php
// hospital/index.php
require_once "../includes/auth.php";
requireRole(['Hospital']);

$user_id = $_SESSION['id'];
$stmt = $pdo->prepare("SELECT * FROM hospitals WHERE user_id = ?");
$stmt->execute([$user_id]);
$hospital = $stmt->fetch(PDO::FETCH_ASSOC);
$hospital_id = $hospital['id'];

// Actions for Organ Verification by hospital
$msg = "";
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['verify_request_id'])) {
    if(!$hospital['verified']) {
        $msg = "<div class='alert alert-danger'>Action Rejected: You must be verified by a system admin to approve medical requests.</div>";
    } else {
        $req_id = $_POST['verify_request_id'];
        // Update request to 'Verified' and assign this hospital ID
        $s = $pdo->prepare("UPDATE organ_requests SET status = 'Verified', hospital_id = ? WHERE id = ?");
        if($s->execute([$hospital_id, $req_id])) {
            $msg = "<div class='alert alert-success'>Organ request clinically verified and broadcasted to the intelligent donor matching network!</div>";
        }
    }
}

// Complete request action
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['complete_request_id'])) {
    if(!$hospital['verified']) {
        $msg = "<div class='alert alert-danger'>Action Rejected: You must be verified by a system admin to proceed.</div>";
    } else {
        $req_id = $_POST['complete_request_id'];
        
        $pdo->beginTransaction();
        try {
            $pdo->prepare("UPDATE organ_requests SET status = 'Completed' WHERE id = ?")->execute([$req_id]);
            $pdo->prepare("UPDATE donations SET status = 'Completed' WHERE request_id = ? AND donation_type = 'Organ'")->execute([$req_id]);
            $pdo->commit();
            $msg = "<div class='alert alert-success'>Procedure marked as completed. The log is permanently saved for audits.</div>";
        } catch (Exception $e) {
            $pdo->rollBack();
            $msg = "<div class='alert alert-danger'>Failed to update transaction state. Error context logged.</div>";
        }
    }
}


// Fetch Pending unverified organ requests globally
$pending_reqs = $pdo->query("SELECT o.id, p.full_name, o.organ_needed, o.priority, o.request_date, o.priority_score 
                             FROM organ_requests o JOIN patients p ON o.patient_id = p.id 
                             WHERE o.status = 'Pending' ORDER BY o.priority_score DESC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch requests verified by THIS hospital
$stmt = $pdo->prepare("SELECT o.id, p.full_name, o.organ_needed, o.status, d.full_name as donor_name, don.match_date 
                       FROM organ_requests o 
                       JOIN patients p ON o.patient_id = p.id 
                       LEFT JOIN donations don ON o.id = don.request_id AND don.donation_type = 'Organ'
                       LEFT JOIN donors d ON don.donor_id = d.id
                       WHERE o.hospital_id = ? ORDER BY o.request_date DESC");
$stmt->execute([$hospital_id]);
$our_reqs = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once "../includes/header.php";
?>
<div class="dashboard-container">
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="index.php" class="active">Hospital Dashboard</a></li>
            <li><a href="profile.php">Update Profile</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Hospital Operations Pipeline</h2>
        
        <?php echo $msg; ?>

        <div class="card" style="margin-bottom:20px;">
            <h3 style="color:var(--primary-teal);">New Transplant Requests (Pending Medical Verification)</h3>
            <p style="font-size:0.9rem; color:gray;">Hospitals must physically verify and approve organ requests before they are broadcasted to matching donors across the global network.</p>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Req ID</th>
                            <th>Patient Name</th>
                            <th>Organ Required</th>
                            <th>Priority</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($pending_reqs as $r): ?>
                        <tr>
                            <td>#O-<?php echo htmlspecialchars($r['id']); ?></td>
                            <td><?php echo htmlspecialchars($r['full_name']); ?></td>
                            <td><strong style="color:var(--primary-teal);"><?php echo htmlspecialchars($r['organ_needed']); ?></strong></td>
                            <td><?php echo htmlspecialchars($r['priority']); ?></td>
                            <td>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('You are clinically verifying this transplant requirement. It will now enter the intelligent matching system under your Hospital\'s jurisdiction. Confirm action?');">
                                    <input type="hidden" name="verify_request_id" value="<?php echo $r['id']; ?>">
                                    <button class="btn btn-teal" style="padding: 4px 10px; font-size:0.85rem;" <?php if(!$hospital['verified']) echo 'disabled title="Requires Admin Approval First"'; ?>>Verify & Claim Requirement</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($pending_reqs)) echo "<tr><td colspan='5'>No pending global requests requiring verification.</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card">
            <h3>Registered Transplants (Managed by <?php echo htmlspecialchars($hospital['hospital_name']); ?>)</h3>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Req ID</th>
                            <th>Patient Identity</th>
                            <th>Organ</th>
                            <th>Matching Status</th>
                            <th>Matched Donor Details</th>
                            <th>Surgical Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($our_reqs as $r): ?>
                        <tr>
                            <td>#O-<?php echo htmlspecialchars($r['id']); ?></td>
                            <td><?php echo htmlspecialchars($r['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($r['organ_needed']); ?></td>
                            <td>
                                <?php 
                                    $class = "status-verified";
                                    if($r['status'] == 'Matched') $class = "status-matched";
                                    if($r['status'] == 'Completed') $class = "status-completed";
                                ?>
                                <span class="status-badge <?php echo $class; ?>"><?php echo htmlspecialchars($r['status']); ?></span>
                            </td>
                            <td>
                                <?php if($r['donor_name']): ?>
                                    <strong style="color:var(--primary-teal);"><?php echo htmlspecialchars($r['donor_name']); ?></strong><br>
                                    <small style="color:gray;">Pledged on: <?php echo date('M d, Y', strtotime($r['match_date'])); ?></small>
                                <?php else: ?>
                                    <span style="color:gray;">Awaiting Matrix Match...</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($r['status'] == 'Matched'): ?>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Confirming procedure completion permanently locks this transplant log. Are you sure?');">
                                    <input type="hidden" name="complete_request_id" value="<?php echo $r['id']; ?>">
                                    <button class="btn btn-primary" style="padding: 4px 10px; font-size:0.85rem;">Mark Surgery Complete</button>
                                </form>
                                <?php else: ?>
                                    <span style="color:silver;">Unavailable</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($our_reqs)) echo "<tr><td colspan='6'>You are not managing any verified transplant requests currently.</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once "../includes/footer.php"; ?>

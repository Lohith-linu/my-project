<?php
// hospital/profile.php
require_once "../includes/auth.php";
requireRole(['Hospital']);

$user_id = $_SESSION['id'];
$msg = "";

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $hospital_name = trim($_POST['hospital_name']);
    $license_no = trim($_POST['license_no']);
    $location_coords = trim($_POST['location_coords']);

    $sql = "UPDATE hospitals SET hospital_name=?, license_no=?, location_coords=? WHERE user_id=?";
    $stmt = $pdo->prepare($sql);
    if($stmt->execute([$hospital_name, $license_no, $location_coords, $user_id])){
        $msg = "Hospital Profile updated successfully!";
    } else {
        $msg = "Error updating profile.";
    }
}

$stmt = $pdo->prepare("SELECT * FROM hospitals WHERE user_id = ?");
$stmt->execute([$user_id]);
$hospital = $stmt->fetch(PDO::FETCH_ASSOC);

require_once "../includes/header.php";
?>
<div class="dashboard-container">
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="index.php">Hospital Dashboard</a></li>
            <li><a href="profile.php" class="active">Update Profile</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Hospital Verification Profile</h2>
        <div class="card" style="max-width: 600px;">
            <?php if(!$hospital['verified']): ?>
                <div class="alert alert-danger" style="margin-bottom:20px;">Your hospital account is currently <strong>UNVERIFIED</strong>. You will not be able to verify organ requests until an Administrator approves your account based on your License No.</div>
            <?php else: ?>
                <div class="alert alert-success" style="margin-bottom:20px;">Your hospital account is <strong>VERIFIED</strong>. You are authorized to manage organ transplant requests for patients in the network.</div>
            <?php endif; ?>

            <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>
            <form method="POST">
                <div class="form-group">
                    <label>Hospital/Institution Name</label>
                    <input type="text" name="hospital_name" class="form-control" value="<?php echo htmlspecialchars($hospital['hospital_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Official Medical License No.</label>
                    <input type="text" name="license_no" class="form-control" value="<?php echo htmlspecialchars($hospital['license_no']); ?>" required>
                    <small style="color:red;">Administrators will verify this license before granting network access.</small>
                </div>
                <div class="form-group">
                    <label>Location Coordinates (Lat,Lng format)</label>
                    <input type="text" name="location_coords" class="form-control" value="<?php echo htmlspecialchars($hospital['location_coords']); ?>" placeholder="e.g. 40.7128,-74.0060" required>
                    <small style="color:gray;">Used by the algorithms to calculate the proximity to the organ donors during a match.</small>
                </div>
                <button type="submit" class="btn btn-primary" style="margin-top:10px;">Save Profile Configuration</button>
            </form>
        </div>
    </div>
</div>
<?php require_once "../includes/footer.php"; ?>

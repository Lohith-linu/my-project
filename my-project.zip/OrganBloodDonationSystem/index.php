<?php
// index.php
require_once "includes/header.php";
?>

<div class="hero">
    <div class="hero-content">
        <h1>Give the Gift of Life</h1>
        <p>Join thousands of others in our mission to save lives through organ and blood donations. Your single act can be a miracle for someone else.</p>
        <div class="hero-buttons">
            <?php if(!isset($_SESSION["loggedin"])): ?>
                <a href="register.php" class="btn btn-primary">Become a Donor</a>
                <a href="register.php" class="btn btn-teal">Request Assistance</a>
            <?php else: ?>
                <?php
                    $dashboardPath = "";
                    if($_SESSION["role"] == 'Admin') $dashboardPath = "admin/index.php";
                    elseif($_SESSION["role"] == 'Donor') $dashboardPath = "donor/index.php";
                    elseif($_SESSION["role"] == 'Patient') $dashboardPath = "patient/index.php";
                    elseif($_SESSION["role"] == 'Hospital') $dashboardPath = "hospital/index.php";
                ?>
                <a href="<?php echo $dashboardPath; ?>" class="btn btn-primary">Go to Dashboard</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="main-content">
    <div class="grid-cards" style="max-width: 1200px; margin: 0 auto;">
        <div class="card" style="text-align: center;">
            <h2 style="color: var(--primary-red); font-size: 2.5rem;">🩸</h2>
            <h3>Blood Donation</h3>
            <p>Every drop counts. A single pint can save three lives. Join our network of blood heroes and help ensure a stable blood supply for emergencies.</p>
        </div>
        <div class="card" style="text-align: center;">
            <h2 style="color: var(--primary-teal); font-size: 2.5rem;">🫀</h2>
            <h3>Organ Donation</h3>
            <p>Leave a legacy of life. Register as an organ donor and give someone a second chance. Our matching algorithm efficiently connects patients in need.</p>
        </div>
        <div class="card" style="text-align: center;">
            <h2 style="color: #f39c12; font-size: 2.5rem;">🏥</h2>
            <h3>Hospital Network</h3>
            <p>Verified hospitals and transplant centers connected in real-time to facilitate matches, ensure compatibility, and update availability statuses.</p>
        </div>
    </div>
</div>

<?php
require_once "includes/footer.php";
?>

<?php
// register.php
require_once "includes/auth.php";
$error = "";

redirectBasedOnRole();

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    $role = trim($_POST["role"]);

    if(empty($username) || empty($password) || empty($role)){
        $error = "Please fill all fields.";
    } else {
        // Check if username exists
        $sql = "SELECT id FROM users WHERE username = :username";
        if($stmt = $pdo->prepare($sql)){
            $stmt->bindParam(":username", $username, PDO::PARAM_STR);
            if($stmt->execute()){
                if($stmt->rowCount() == 1){
                    $error = "This username is already taken.";
                } else {
                    // Create user
                    $sql_insert_user = "INSERT INTO users (username, password_hash, role) VALUES (:username, :password_hash, :role)";
                    if($stmt_insert = $pdo->prepare($sql_insert_user)){
                        $param_password = password_hash($password, PASSWORD_DEFAULT);
                        $stmt_insert->bindParam(":username", $username, PDO::PARAM_STR);
                        $stmt_insert->bindParam(":password_hash", $param_password, PDO::PARAM_STR);
                        $stmt_insert->bindParam(":role", $role, PDO::PARAM_STR);
                        
                        if($stmt_insert->execute()){
                            $new_user_id = $pdo->lastInsertId();
                            
                            // Initialize role profile
                            if($role == "Donor") {
                                $pdo->query("INSERT INTO donors (user_id, full_name, blood_group, contact_info, location_coords) VALUES ($new_user_id, 'Update Profile', 'O+', 'Update Contact', '0,0')");
                            } elseif($role == "Patient") {
                                $pdo->query("INSERT INTO patients (user_id, full_name, blood_group, contact_info, location_coords) VALUES ($new_user_id, 'Update Profile', 'O+', 'Update Contact', '0,0')");
                            } elseif($role == "Hospital") {
                                $pdo->query("INSERT INTO hospitals (user_id, hospital_name, license_no, location_coords) VALUES ($new_user_id, 'Update Name', 'LIC-$new_user_id', '0,0')");
                            }
                            // Admin role needs no further initialization profile here
                            
                            header("location: /OrganBloodDonationSystem/login.php");
                            exit;
                        } else {
                            $error = "Something went wrong. Please try again later.";
                        }
                    }
                }
            }
            unset($stmt);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Donation System</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-body">
    <div class="auth-wrapper">
        <div class="auth-card">
            <div class="auth-header">
                <h2>Create Account</h2>
                <p>Register to the Organ & Blood Donation System</p>
            </div>
            <?php 
            if(!empty($error)){
                echo '<div class="alert alert-danger">' . $error . '</div>';
            }        
            ?>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" required placeholder="Choose a username">
                </div>    
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" required placeholder="Create a password">
                </div>
                <div class="form-group">
                    <label>Role</label>
                    <select name="role" class="form-control" required>
                        <option value="">Select Role</option>
                        <option value="Donor">Donor</option>
                        <option value="Patient">Patient</option>
                        <option value="Hospital">Hospital</option>
                        <option value="Admin">Administrator</option>
                    </select>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-block">Register</button>
                </div>
                <div class="auth-footer">
                    <p>Already have an account? <a href="login.php">Login here</a></p>
                    <p><a href="index.php">Back to Home</a></p>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

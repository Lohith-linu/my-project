<?php
// includes/footer.php
?>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> LifeFlow - Organ & Blood Donation System. All Rights Reserved. Built securely using PHP & MySQL.</p>
    </footer>
</body>
</html>

<?php
// includes/auth.php
session_start();
require_once 'config.php';

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true;
}

// Require a specific role to access a page
function requireRole($allowedRoles) {
    if(!isLoggedIn() || !in_array($_SESSION["role"], $allowedRoles)) {
        header("location: /OrganBloodDonationSystem/login.php");
        exit;
    }
}

// Redirect already logged-in users to their respective dashboards
function redirectBasedOnRole() {
    if(isLoggedIn()){
        switch($_SESSION["role"]) {
            case 'Admin':
                header("location: /OrganBloodDonationSystem/admin/index.php");
                exit;
            case 'Donor':
                header("location: /OrganBloodDonationSystem/donor/index.php");
                exit;
            case 'Patient':
                header("location: /OrganBloodDonationSystem/patient/index.php");
                exit;
            case 'Hospital':
                header("location: /OrganBloodDonationSystem/hospital/index.php");
                exit;
        }
    }
}
?>

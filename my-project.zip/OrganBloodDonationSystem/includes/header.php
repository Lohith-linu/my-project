<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LifeFlow - Organ & Blood Donation</title>
    <!-- Modern universal styling -->
    <link rel="stylesheet" href="/OrganBloodDonationSystem/assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-brand">
            <a href="/OrganBloodDonationSystem/index.php" style="color: inherit; text-decoration: none;">🩸 LifeFlow</a>
        </div>
        <ul class="nav-links">
            <li><a href="/OrganBloodDonationSystem/index.php">Home</a></li>
            <?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true): ?>
                <?php
                    $dashboardPath = "";
                    if($_SESSION["role"] == 'Admin') $dashboardPath = "/OrganBloodDonationSystem/admin/index.php";
                    elseif($_SESSION["role"] == 'Donor') $dashboardPath = "/OrganBloodDonationSystem/donor/index.php";
                    elseif($_SESSION["role"] == 'Patient') $dashboardPath = "/OrganBloodDonationSystem/patient/index.php";
                    elseif($_SESSION["role"] == 'Hospital') $dashboardPath = "/OrganBloodDonationSystem/hospital/index.php";
                ?>
                <li><a href="<?php echo $dashboardPath; ?>">Dashboard (<?php echo $_SESSION["role"]; ?>)</a></li>
                <li><a href="/OrganBloodDonationSystem/logout.php" class="btn btn-outline" style="padding: 5px 15px;">Logout</a></li>
            <?php else: ?>
                <li><a href="/OrganBloodDonationSystem/login.php">Login</a></li>
                <li><a href="/OrganBloodDonationSystem/register.php" class="btn btn-primary">Register</a></li>
            <?php endif; ?>
        </ul>
    </nav>

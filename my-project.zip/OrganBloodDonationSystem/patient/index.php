<?php
// patient/index.php
require_once "../includes/auth.php";
requireRole(['Patient']);

$user_id = $_SESSION['id'];
$stmt = $pdo->prepare("SELECT * FROM patients WHERE user_id = ?");
$stmt->execute([$user_id]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch their requests
$stmt_blood = $pdo->prepare("SELECT * FROM blood_requests WHERE patient_id = ? ORDER BY request_date DESC");
$stmt_blood->execute([$patient['id']]);
$blood_reqs = $stmt_blood->fetchAll(PDO::FETCH_ASSOC);

$stmt_organ = $pdo->prepare("SELECT * FROM organ_requests WHERE patient_id = ? ORDER BY request_date DESC");
$stmt_organ->execute([$patient['id']]);
$organ_reqs = $stmt_organ->fetchAll(PDO::FETCH_ASSOC);

require_once "../includes/header.php";
?>
<div class="dashboard-container">
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="index.php" class="active">Patient Dashboard</a></li>
            <li><a href="profile.php">Update Profile</a></li>
            <li><a href="request.php">Make a Request</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Welcome, <?php echo htmlspecialchars($patient['full_name']); ?>!</h2>
        
        <div class="card" style="margin-bottom: 20px;">
            <h3>Your Registered Medical Profile</h3>
            <p><strong>Blood Group:</strong> <span style="color:var(--primary-red);font-weight:bold;"><?php echo htmlspecialchars($patient['blood_group']); ?></span></p>
            <p><strong>Contact:</strong> <?php echo htmlspecialchars($patient['contact_info']); ?></p>
            <p><strong>Region/Coords:</strong> <?php echo htmlspecialchars($patient['location_coords']); ?></p>
        </div>

        <div class="card">
            <h3 style="color: var(--primary-red);">Your Blood Component Requests</h3>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Req ID</th>
                            <th>Blood Group Needed</th>
                            <th>Volume</th>
                            <th>Priority</th>
                            <th>Base Score</th>
                            <th>System Status</th>
                            <th>Creation Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($blood_reqs as $r): ?>
                        <tr>
                            <td>#B-<?php echo htmlspecialchars($r['id']); ?></td>
                            <td><?php echo htmlspecialchars($r['blood_group_needed']); ?></td>
                            <td><?php echo htmlspecialchars($r['volume_ml']); ?>ml</td>
                            <td>
                                <?php 
                                    $p_color = '#28a745';
                                    if($r['priority'] == 'Critical') $p_color = '#dc3545';
                                    elseif($r['priority'] == 'Urgent') $p_color = '#ffc107';
                                ?>
                                <span style="color:<?php echo $p_color; ?>;font-weight:bold;"><?php echo htmlspecialchars($r['priority']); ?></span>
                            </td>
                            <td><span style="background:#007bff;color:white;padding:3px 8px;border-radius:10px;font-weight:bold;"><?php echo round($r['priority_score'] ?? 0,1); ?></span></td>
                            <td>
                                <?php 
                                    $class = "status-pending";
                                    if($r['status'] == 'Approved') $class = "status-approved";
                                    if($r['status'] == 'Fulfilled') $class = "status-completed";
                                ?>
                                <span class="status-badge <?php echo $class; ?>"><?php echo htmlspecialchars($r['status']); ?></span>
                            </td>
                            <td><?php echo htmlspecialchars(date('M d, Y', strtotime($r['request_date']))); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($blood_reqs)) echo "<tr><td colspan='5'>You have not made any blood requests.</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card" style="margin-top:20px;">
            <h3 style="color: var(--primary-teal);">Your Organ Transplant Requests</h3>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Req ID</th>
                            <th>Organ Needed</th>
                            <th>Priority</th>
                            <th>Base Score</th>
                            <th>System Status</th>
                            <th>Creation Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($organ_reqs as $r): ?>
                        <tr>
                            <td>#O-<?php echo htmlspecialchars($r['id']); ?></td>
                            <td><?php echo htmlspecialchars($r['organ_needed']); ?></td>
                            <td>
                                <?php 
                                    $p_color = '#28a745';
                                    if($r['priority'] == 'Critical') $p_color = '#dc3545';
                                    elseif($r['priority'] == 'Urgent') $p_color = '#ffc107';
                                ?>
                                <span style="color:<?php echo $p_color; ?>;font-weight:bold;"><?php echo htmlspecialchars($r['priority']); ?></span>
                            </td>
                            <td><span style="background:#007bff;color:white;padding:3px 8px;border-radius:10px;font-weight:bold;"><?php echo round($r['priority_score'] ?? 0,1); ?></span></td>
                            <td>
                                <?php 
                                    $class = "status-pending";
                                    if($r['status'] == 'Verified') $class = "status-verified";
                                    if($r['status'] == 'Matched') $class = "status-matched";
                                    if($r['status'] == 'Completed') $class = "status-completed";
                                ?>
                                <span class="status-badge <?php echo $class; ?>"><?php echo htmlspecialchars($r['status']); ?></span>
                            </td>
                            <td><?php echo htmlspecialchars(date('M d, Y', strtotime($r['request_date']))); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($organ_reqs)) echo "<tr><td colspan='5'>You have not made any organ requests.</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once "../includes/footer.php"; ?>

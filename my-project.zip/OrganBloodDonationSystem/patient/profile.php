<?php
// patient/profile.php
require_once "../includes/auth.php";
requireRole(['Patient']);

$user_id = $_SESSION['id'];
$msg = "";

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $full_name = trim($_POST['full_name']);
    $blood_group = trim($_POST['blood_group']);
    $contact_info = trim($_POST['contact_info']);
    $location_coords = trim($_POST['location_coords']);
    $age = (int)$_POST['age'];

    $sql = "UPDATE patients SET full_name=?, blood_group=?, contact_info=?, location_coords=?, age=? WHERE user_id=?";
    $stmt = $pdo->prepare($sql);
    if($stmt->execute([$full_name, $blood_group, $contact_info, $location_coords, $age, $user_id])){
        $msg = "Patient Profile updated successfully!";
    } else {
        $msg = "Error updating patient profile.";
    }
}

$stmt = $pdo->prepare("SELECT * FROM patients WHERE user_id = ?");
$stmt->execute([$user_id]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

require_once "../includes/header.php";
?>
<div class="dashboard-container">
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="index.php">Patient Dashboard</a></li>
            <li><a href="profile.php" class="active">Update Profile</a></li>
            <li><a href="request.php">Make a Request</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Update Patient Profile</h2>
        <div class="card" style="max-width: 600px;">
            <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>
            <form method="POST">
                <div class="form-group">
                    <label>Legal Full Name</label>
                    <input type="text" name="full_name" class="form-control" value="<?php echo htmlspecialchars($patient['full_name'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label>Age</label>
                    <input type="number" name="age" class="form-control" value="<?php echo htmlspecialchars($patient['age'] ?? '30'); ?>" required>
                </div>
                <div class="form-group">
                    <label>Your Blood Group</label>
                    <select name="blood_group" class="form-control" required>
                        <?php 
                        $bgs = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
                        foreach($bgs as $bg){
                            $sel = ($patient['blood_group'] == $bg) ? 'selected' : '';
                            echo "<option value='$bg' $sel>$bg</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Contact Number / Identity</label>
                    <input type="text" name="contact_info" class="form-control" value="<?php echo htmlspecialchars($patient['contact_info']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Location Coordinates (Lat,Lng format)</label>
                    <input type="text" name="location_coords" class="form-control" value="<?php echo htmlspecialchars($patient['location_coords']); ?>" placeholder="e.g. 40.7128,-74.0060" required>
                    <small style="color:gray;">Providing accurate geographical location drastically improves your position in the Priority Matching Algorithm by matching with closer donors.</small>
                </div>
                <button type="submit" class="btn btn-primary" style="margin-top:10px;">Save Profile</button>
            </form>
        </div>
    </div>
</div>
<?php require_once "../includes/footer.php"; ?>

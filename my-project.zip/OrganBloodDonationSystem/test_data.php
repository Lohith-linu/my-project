<?php
$pdo = new PDO('mysql:host=localhost;dbname=organ_blood_donation', 'root', '');

// Insert patients first
$patients = [
    ['Ravi Kumar', 'O+'],
    ['Anjali Sharma', 'O+'],
    ['Rahul Verma', 'O+']
];

$req_data = [
    // [waiting_days, distance]
    [5, 5],
    [3, 15],
    [1, 40]
];

foreach ($patients as $idx => $p) {
    $pdo->query("INSERT INTO users (username, password_hash, role) VALUES ('patient_test_" . rand(1000,9999) . "', 'hash', 'Patient')");
    $uid = $pdo->lastInsertId();
    $pdo->query("INSERT INTO patients (user_id, full_name, blood_group, contact_info, location_coords) VALUES ($uid, '{$p[0]}', '{$p[1]}', '123', '0,0')");
    $pid = $pdo->lastInsertId();
    
    $days = $req_data[$idx][0];
    $dist = $req_data[$idx][1];
    
    // Simulate "request_date" based on waiting days exactly
    $req_date = date('Y-m-d H:i:s', time() - ($days * 86400));
    
    $pdo->query("INSERT INTO blood_requests (patient_id, blood_group_needed, volume_ml, priority, distance, status, request_date) 
                 VALUES ($pid, '{$p[1]}', 200, 'Critical', $dist, 'Pending', '$req_date')");
}
echo "Dummy data inserted!";
?>

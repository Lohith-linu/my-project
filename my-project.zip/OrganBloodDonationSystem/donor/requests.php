<?php
// donor/requests.php
// Donor views requests that match their profile, sorted by urgency and priority.
require_once "../includes/auth.php";
requireRole(['Donor']);

$user_id = $_SESSION['id'];
$stmt = $pdo->prepare("SELECT * FROM donors WHERE user_id = ?");
$stmt->execute([$user_id]);
$donor = $stmt->fetch(PDO::FETCH_ASSOC);

// Haversine distance function in PHP to sort by proximity
function distance($lat1, $lon1, $lat2, $lon2) {
    if (($lat1 == $lat2) && ($lon1 == $lon2)) return 0;
    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
    return $miles * 1.609344; // in kilometers
}

// Logic to fetch compatible blood requests
// Standard O- is universal donor, AB+ is universal receiver etc. For simplicity, we just use exact match + universal donor simulation here.
$bloodGroupQuery = " AND blood_group_needed = '" . $donor['blood_group'] . "' ";
if($donor['blood_group'] == 'O-') $bloodGroupQuery = ""; // Universal donor can see all

$blood_reqs = [];
if($donor['is_available']){
    // In our system logic, Patient's requests are Approved by admin/system before Donor sees them.
    $q = $pdo->query("SELECT r.*, p.full_name, p.location_coords, p.blood_group, p.age 
                      FROM blood_requests r 
                      JOIN patients p ON r.patient_id = p.id 
                      WHERE r.status = 'Approved' {$bloodGroupQuery}");
    $blood_reqs = $q->fetchAll(PDO::FETCH_ASSOC);
}

// Organ compatibility
$organ_reqs = [];
if($donor['is_available'] && $donor['organ_offered'] !== 'None'){
    // Organ requests must be verified by a Hospital before matching
    $q2 = $pdo->prepare("SELECT r.*, p.full_name, h.location_coords as hospital_loc, p.age 
                         FROM organ_requests r 
                         JOIN patients p ON r.patient_id = p.id 
                         JOIN hospitals h ON r.hospital_id = h.id 
                         WHERE r.status = 'Verified' AND r.organ_needed = ?");
    $q2->execute([$donor['organ_offered']]);
    $organ_reqs = $q2->fetchAll(PDO::FETCH_ASSOC);
}

// Sort by Priority Algorithm
// Priority Score = (Urgency_Level * 10) - (Distance_in_km * 0.1) + (Days_waiting * 2)
function calculatePriorityScore(&$reqs, $donor_loc) {
    if(empty($donor_loc) || strpos($donor_loc, ',') === false) $donor_loc = "0,0";
    list($dlat, $dlng) = explode(',', $donor_loc);
    
    foreach($reqs as &$r){
        $loc = isset($r['hospital_loc']) ? $r['hospital_loc'] : $r['location_coords'];
        if(empty($loc) || strpos($loc, ',') === false) $loc = "0,0";
        list($plat, $plng) = explode(',', $loc);
        
        $dist = distance($dlat, $dlng, $plat, $plng);
        $days_waiting = (time() - strtotime($r['request_date'])) / (60 * 60 * 24);
        if($days_waiting < 0) $days_waiting = 0; // fallback
        
        $urgencyScore = 40;
        if($r['priority'] == 'Critical') $urgencyScore = 100;
        elseif($r['priority'] == 'Urgent') $urgencyScore = 70;

        $waitingScore = $days_waiting * 2;
        $distanceScore = 100 - $dist;
        
        $ageScore = 0;
        $patient_age = isset($r['age']) ? (int)$r['age'] : 30;
        if($patient_age < 12) $ageScore = 30;
        elseif($patient_age > 60) $ageScore = 20;

        // Final metric Score
        $r['priority_score'] = $urgencyScore + $waitingScore + $distanceScore + $ageScore;
        $r['distance_km'] = round($dist, 1);
        
        if($r['priority'] == 'Critical') $r['p_color'] = '#dc3545'; // red
        elseif($r['priority'] == 'Urgent') $r['p_color'] = '#ffc107'; // yellow
        else $r['p_color'] = '#28a745'; // green // normal
    }
    
    usort($reqs, function($a, $b) {
        if (round($b['priority_score'], 5) == round($a['priority_score'], 5)) {
            return strtotime($a['request_date']) <=> strtotime($b['request_date']);
        }
        return $b['priority_score'] <=> $a['priority_score'];
    });
}

calculatePriorityScore($blood_reqs, $donor['location_coords']);
calculatePriorityScore($organ_reqs, $donor['location_coords']);

// Handle Donate Action
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['donate_type'], $_POST['request_id'])) {
    $type = $_POST['donate_type'];
    $req_id = $_POST['request_id'];
    
    $pdo->beginTransaction();
    try {
        // Create donation fulfillment link record
        $stmt = $pdo->prepare("INSERT INTO donations (donor_id, request_id, donation_type, status) VALUES (?, ?, ?, 'Matched')");
        $stmt->execute([$donor['id'], $req_id, $type]);
        
        // Update request terminal status
        if($type == 'Blood') {
            $pdo->prepare("UPDATE blood_requests SET status = 'Fulfilled' WHERE id = ?")->execute([$req_id]);
        } else {
            $pdo->prepare("UPDATE organ_requests SET status = 'Matched' WHERE id = ?")->execute([$req_id]);
        }
        
        // Update donor availability to prevent double pledging instantaneously
        $pdo->prepare("UPDATE donors SET is_available = 0 WHERE id = ?")->execute([$donor['id']]);
        
        $pdo->commit();
        header("Location: index.php");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Transaction failed! Please try again.";
    }
}

require_once "../includes/header.php";
?>
<div class="dashboard-container">
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="index.php">Donor Dashboard</a></li>
            <li><a href="profile.php">Update Profile</a></li>
            <li><a href="requests.php" class="active">Matching Requests</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Intelligent Matching Algorithm Results</h2>
        <p>Showing highest priority compatible patients based on: Urgency, Blood Type, Location Proximity, and Wait duration.</p>

        <?php if(!$donor['is_available']): ?>
            <div class="alert alert-danger" style="margin-top:20px;">You are currently marked as unavailable. Update your profile availability flag to participate in matching network.</div>
        <?php else: ?>
            <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

            <div class="card" style="margin-top:20px;">
                <h3 style="color: var(--primary-red);">🩸 Compatible Blood Requests <?php if($donor['blood_group'] == 'O-') echo "(Universal O- Donor)"; ?></h3>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Match Score</th>
                                <th>Patient Name</th>
                                <th>Blood Type Required</th>
                                <th>Volume</th>
                                <th>Priority</th>
                                <th>Distance</th>
                                <th>Wait Time</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($blood_reqs as $idx => $r): ?>
                            <tr style="<?php if($idx == 0) echo 'background-color:#fff3cd;border-left:4px solid #ffc107;'; ?>">
                                <td><span style="background:#007bff;color:white;padding:3px 8px;border-radius:10px;font-weight:bold;"><?php echo round($r['priority_score'],1); ?></span></td>
                                <td><?php echo htmlspecialchars($r['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($r['blood_group_needed']); ?></td>
                                <td><?php echo htmlspecialchars($r['volume_ml']); ?>ml</td>
                                <td><span style="color:<?php echo $r['p_color']; ?>;font-weight:bold;"><?php echo htmlspecialchars($r['priority']); ?></span></td>
                                <td><?php echo htmlspecialchars($r['distance_km']); ?> km</td>
                                <td><?php echo round((time() - strtotime($r['request_date']))/86400); ?> days</td>
                                <td>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Confirm Donation Pledge? This will notify the patient and mark you as fulfilled.');">
                                        <input type="hidden" name="donate_type" value="Blood">
                                        <input type="hidden" name="request_id" value="<?php echo $r['id']; ?>">
                                        <button class="btn btn-primary" style="padding: 4px 10px; font-size: 0.85rem;">Pledge Donation</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($blood_reqs)) echo "<tr><td colspan='8'>No compatible blood requests found matching your profile at this moment.</td></tr>"; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if($donor['organ_offered'] !== 'None'): ?>
            <div class="card">
                <h3 style="color: var(--primary-teal);">🫀 Compatible Organ Requests (<?php echo htmlspecialchars($donor['organ_offered']); ?>)</h3>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Match Score</th>
                                <th>Patient Name</th>
                                <th>Priority</th>
                                <th>Distance (to Hosp)</th>
                                <th>Wait Time</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($organ_reqs as $idx => $r): ?>
                            <tr style="<?php if($idx == 0) echo 'background-color:#fff3cd;border-left:4px solid #ffc107;'; ?>">
                                <td><span style="background:#007bff;color:white;padding:3px 8px;border-radius:10px;font-weight:bold;"><?php echo round($r['priority_score'],1); ?></span></td>
                                <td><?php echo htmlspecialchars($r['full_name']); ?></td>
                                <td><span style="color:<?php echo $r['p_color']; ?>;font-weight:bold;"><?php echo htmlspecialchars($r['priority']); ?></span></td>
                                <td><?php echo htmlspecialchars($r['distance_km']); ?> km</td>
                                <td><?php echo round((time() - strtotime($r['request_date']))/86400); ?> days</td>
                                <td>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Confirm Organ Donation Match? Life saving decision.');">
                                        <input type="hidden" name="donate_type" value="Organ">
                                        <input type="hidden" name="request_id" value="<?php echo $r['id']; ?>">
                                        <button class="btn btn-teal" style="padding: 4px 10px; font-size: 0.85rem;">Pledge Match</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($organ_reqs)) echo "<tr><td colspan='6'>No compatible organ requests found at this moment.</td></tr>"; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

        <?php endif; ?>
    </div>
</div>
<?php require_once "../includes/footer.php"; ?>

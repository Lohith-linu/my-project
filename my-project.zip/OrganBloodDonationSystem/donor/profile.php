<?php
// donor/profile.php
require_once "../includes/auth.php";
requireRole(['Donor']);

$user_id = $_SESSION['id'];
$msg = "";

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $full_name = trim($_POST['full_name']);
    $blood_group = trim($_POST['blood_group']);
    $organ_offered = trim($_POST['organ_offered']);
    $contact_info = trim($_POST['contact_info']);
    $location_coords = trim($_POST['location_coords']);
    $is_available = isset($_POST['is_available']) ? 1 : 0;

    $sql = "UPDATE donors SET full_name=?, blood_group=?, organ_offered=?, contact_info=?, location_coords=?, is_available=? WHERE user_id=?";
    $stmt = $pdo->prepare($sql);
    if($stmt->execute([$full_name, $blood_group, $organ_offered, $contact_info, $location_coords, $is_available, $user_id])){
        $msg = "Profile updated successfully!";
    } else {
        $msg = "Error updating profile.";
    }
}

$stmt = $pdo->prepare("SELECT * FROM donors WHERE user_id = ?");
$stmt->execute([$user_id]);
$donor = $stmt->fetch(PDO::FETCH_ASSOC);

require_once "../includes/header.php";
?>
<div class="dashboard-container">
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="index.php">Donor Dashboard</a></li>
            <li><a href="profile.php" class="active">Update Profile</a></li>
            <li><a href="requests.php">Matching Requests</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Update Donor Profile</h2>
        <div class="card" style="max-width: 600px;">
            <?php if($msg) echo "<div class='alert alert-success'>$msg</div>"; ?>
            <form method="POST">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" class="form-control" value="<?php echo htmlspecialchars($donor['full_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Blood Group</label>
                    <select name="blood_group" class="form-control" required>
                        <?php 
                        $bgs = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
                        foreach($bgs as $bg){
                            $sel = ($donor['blood_group'] == $bg) ? 'selected' : '';
                            echo "<option value='$bg' $sel>$bg</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Organ Offered (Optional)</label>
                    <select name="organ_offered" class="form-control" required>
                        <?php 
                        $organs = ['None', 'Kidney', 'Liver', 'Heart', 'Lung', 'Pancreas', 'Cornea', 'Bone Marrow'];
                        foreach($organs as $og){
                            $sel = ($donor['organ_offered'] == $og) ? 'selected' : '';
                            echo "<option value='$og' $sel>$og</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Contact Number</label>
                    <input type="text" name="contact_info" class="form-control" value="<?php echo htmlspecialchars($donor['contact_info']); ?>" required>
                </div>
                <!-- Location simulation -->
                <div class="form-group">
                    <label>Location Coordinates (Lat,Lng format for Matching Algorithm)</label>
                    <input type="text" name="location_coords" class="form-control" value="<?php echo htmlspecialchars($donor['location_coords']); ?>" placeholder="e.g. 40.7128,-74.0060" required>
                    <small style="color:gray;">Used by the priority matching algorithm to find geographically closest patients.</small>
                </div>
                <div class="form-group" style="background:#f4f7f6; padding:10px; border-radius:5px;">
                    <label style="margin-bottom:0; cursor:pointer; display:flex; align-items:center; gap:10px;">
                        <input type="checkbox" name="is_available" value="1" <?php if($donor['is_available']) echo "checked"; ?>>
                        I am currently available to be matched and contacted for donation.
                    </label>
                </div>
                <button type="submit" class="btn btn-primary" style="margin-top:15px;">Save Profile Configuration</button>
            </form>
        </div>
    </div>
</div>
<?php require_once "../includes/footer.php"; ?>

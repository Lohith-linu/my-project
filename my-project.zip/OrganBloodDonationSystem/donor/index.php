<?php
// donor/index.php
require_once "../includes/auth.php";
requireRole(['Donor']);

$user_id = $_SESSION['id'];

// Get donor profile
$stmt = $pdo->prepare("SELECT * FROM donors WHERE user_id = ?");
$stmt->execute([$user_id]);
$donor = $stmt->fetch(PDO::FETCH_ASSOC);

// Get donation history
$stmt_history = $pdo->prepare("SELECT d.id, d.donation_type, d.status, d.match_date 
                               FROM donations d WHERE d.donor_id = ? ORDER BY match_date DESC");
$stmt_history->execute([$donor['id']]);
$history = $stmt_history->fetchAll(PDO::FETCH_ASSOC);

require_once "../includes/header.php";
?>
<div class="dashboard-container">
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="index.php" class="active">Donor Dashboard</a></li>
            <li><a href="profile.php">Update Profile</a></li>
            <li><a href="requests.php">Matching Requests</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h2>Welcome, <?php echo htmlspecialchars($donor['full_name']); ?>!</h2>
        <div class="card" style="margin-bottom: 20px;">
            <h3>Your Profile Status</h3>
            <p><strong>Blood Group:</strong> <span style="color:var(--primary-red);font-weight:bold;"><?php echo htmlspecialchars($donor['blood_group']); ?></span></p>
            <p><strong>Organ Registered for Donation:</strong> <span style="color:var(--primary-teal);font-weight:bold;"><?php echo htmlspecialchars($donor['organ_offered']); ?></span></p>
            <p><strong>Availability:</strong> 
                <?php if($donor['is_available']): ?>
                    <span class="status-badge status-approved">Available for Match</span>
                <?php else: ?>
                    <span class="status-badge status-pending">Not Available</span>
                <?php endif; ?>
            </p>
        </div>

        <div class="card">
            <h3>Your Donation History</h3>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Donation ID</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Match Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($history as $h): ?>
                        <tr>
                            <td>#DON-<?php echo htmlspecialchars($h['id']); ?></td>
                            <td>
                                <?php if($h['donation_type'] == 'Blood') echo '🩸 '; else echo '🫀 '; ?>
                                <?php echo htmlspecialchars($h['donation_type']); ?>
                            </td>
                            <td>
                                <?php 
                                    $class = "status-matched";
                                    if($h['status'] == 'Completed') $class = "status-completed";
                                ?>
                                <span class="status-badge <?php echo $class; ?>"><?php echo htmlspecialchars($h['status']); ?></span>
                            </td>
                            <td><?php echo htmlspecialchars(date('M d, Y', strtotime($h['match_date']))); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($history)) echo "<tr><td colspan='4'>You haven't made any donations yet. Thank you for registering!</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once "../includes/footer.php"; ?>

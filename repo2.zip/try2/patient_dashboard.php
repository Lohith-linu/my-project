<?php
$host = 'localhost';
$dbname = 'organ_blood_donation';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $message = "";

    // Handle Form Submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
        $name = $_POST['name'];
        $age = $_POST['age'];
        $blood_group = $_POST['blood_group'];
        $request_type = $_POST['request_type'];
        $organ_needed = empty($_POST['organ_needed']) ? null : $_POST['organ_needed'];
        $condition = $_POST['condition'];

        $stmt = $pdo->prepare("INSERT INTO patients (name, age, blood_group, request_type, organ_needed, `condition`) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $age, $blood_group, $request_type, $organ_needed, $condition]);

        $target_patient_id = $pdo->lastInsertId();

        // Trigger priority evaluation and automatic matching scoped to ONLY the new insert
        ob_start();
        include 'update_priority.php';
        include 'matching_system.php';
        $debug_output = ob_get_clean();

        $message = "<div class='alert alert-success alert-dismissible fade show' role='alert'>
                        <i class='bi bi-check-circle-fill me-2'></i>Request successfully submitted and matching sequence executed!
                        <hr>
                        <div class='mb-0 small'>" . strip_tags($debug_output, '<p><strong><br>') . "</div>
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>";
    }

    // Fetch Summary Stats
    $totalReq = $pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();
    $approvedReq = $pdo->query("SELECT COUNT(*) FROM patients WHERE status = 'approved'")->fetchColumn();
    $pendingReq = $pdo->query("SELECT COUNT(*) FROM patients WHERE status IN ('pending', 'waiting_for_donor')")->fetchColumn();
    $fulfilledReq = $pdo->query("SELECT COUNT(*) FROM patients WHERE status = 'fulfilled'")->fetchColumn();

    // Fetch All Patients Data
    $patients = $pdo->query("SELECT * FROM patients ORDER BY priority_score DESC, request_date DESC")->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database Connection Error: " . htmlspecialchars($e->getMessage()));
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard | Healthcare System</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f9fe;
            color: #333;
        }

        /* Header Styling */
        .gradient-header {
            background: linear-gradient(135deg, #ff0844 0%, #ffb199 100%);
            color: white;
            padding: 3rem 0;
            border-bottom-left-radius: 40px;
            border-bottom-right-radius: 40px;
            box-shadow: 0 10px 30px rgba(255, 8, 68, 0.2);
            position: relative;
            margin-bottom: 3rem;
            overflow: hidden;
        }

        .gradient-header::after {
            content: '';
            position: absolute;
            top: -50%;
            right: -10%;
            width: 40%;
            height: 200%;
            background: rgba(255, 255, 255, 0.1);
            transform: rotate(-30deg);
            pointer-events: none;
        }

        /* Summary Cards */
        .stat-card {
            background: white;
            border: none;
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            height: 100%;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .stat-total::before {
            background-color: #5e72e4;
        }

        .stat-approved::before {
            background-color: #11cdef;
        }

        .stat-pending::before {
            background-color: #fb6340;
        }

        .stat-fulfilled::before {
            background-color: #2dce89;
        }

        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.2;
            position: absolute;
            right: 1.5rem;
            bottom: 1rem;
        }

        /* Main Table Card */
        .table-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.05);
            padding: 2rem;
            margin-bottom: 3rem;
        }

        .table thead th {
            border-bottom: 2px solid #e9ecef;
            color: #8898aa;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
        }

        .table tbody tr {
            transition: all 0.2s;
        }

        .table tbody tr:hover {
            background-color: #f8f9fe;
            box-shadow: inset 0 0 0 9999px rgba(0, 0, 0, 0.02);
        }

        .table td {
            vertical-align: middle;
            color: #525f7f;
            font-weight: 500;
        }

        /* Status Badges */
        .status-badge {
            padding: 0.4em 1em;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.85rem;
        }

        .badge-pending {
            background-color: rgba(251, 99, 64, 0.1);
            color: #fb6340;
        }

        .badge-approved {
            background-color: rgba(17, 205, 239, 0.1);
            color: #11cdef;
        }

        .badge-waiting {
            background-color: rgba(94, 114, 228, 0.1);
            color: #5e72e4;
        }

        .badge-fulfilled {
            background-color: rgba(45, 206, 137, 0.1);
            color: #2dce89;
        }

        /* Request Button */
        .btn-request {
            background: linear-gradient(135deg, #ff0844 0%, #ffb199 100%);
            color: white;
            border: none;
            border-radius: 50px;
            padding: 0.8rem 2rem;
            font-weight: 600;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(255, 8, 68, 0.3);
        }

        .btn-request:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(255, 8, 68, 0.4);
            color: white;
        }

        .req-type {
            font-weight: 700;
            text-transform: uppercase;
            font-size: 0.8rem;
        }

        .req-blood {
            color: #f5365c;
        }

        .req-organ {
            color: #8965e0;
        }

        .modal-content {
            border-radius: 20px;
            border: none;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%);
            border-bottom: 1px solid #e9ecef;
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
        }
    </style>
</head>

<body>

    <!-- Header Section -->
    <header class="gradient-header">
        <div class="container d-flex justify-content-between align-items-center">
            <div>
                <h1 class="display-5 fw-bold mb-1"><i class="bi bi-heart-pulse-fill me-2"></i>Patient Dashboard</h1>
                <p class="lead mb-0 opacity-75">Track your blood and organ request status in real-time</p>
            </div>
            <div>
                <button class="btn btn-request" data-bs-toggle="modal" data-bs-target="#newRequestModal">
                    <i class="bi bi-plus-lg me-1"></i> Request Blood/Organ
                </button>
            </div>
        </div>
    </header>

    <main class="container">

        <?php if (!empty($message))
            echo $message; ?>

        <!-- Summary Cards -->
        <div class="row g-4 mb-5">
            <div class="col-md-3 col-sm-6">
                <div class="stat-card stat-total d-flex flex-column justify-content-center">
                    <h6 class="text-uppercase text-muted fw-bold mb-1">Total Requests</h6>
                    <h2 class="fw-bold mb-0 text-dark"><?php echo $totalReq; ?></h2>
                    <i class="bi bi-card-list stat-icon text-primary"></i>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card stat-approved d-flex flex-column justify-content-center">
                    <h6 class="text-uppercase text-muted fw-bold mb-1">Approved</h6>
                    <h2 class="fw-bold mb-0 text-dark"><?php echo $approvedReq; ?></h2>
                    <i class="bi bi-check-circle stat-icon text-info"></i>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card stat-pending d-flex flex-column justify-content-center">
                    <h6 class="text-uppercase text-muted fw-bold mb-1">Pending</h6>
                    <h2 class="fw-bold mb-0 text-dark"><?php echo $pendingReq; ?></h2>
                    <i class="bi bi-hourglass-split stat-icon text-warning"></i>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="stat-card stat-fulfilled d-flex flex-column justify-content-center">
                    <h6 class="text-uppercase text-muted fw-bold mb-1">Fulfilled</h6>
                    <h2 class="fw-bold mb-0 text-dark"><?php echo $fulfilledReq; ?></h2>
                    <i class="bi bi-heart-fill stat-icon text-success"></i>
                </div>
            </div>
        </div>

        <!-- Request Table -->
        <div class="table-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-bold m-0 text-dark">Recent Requests Overview</h4>
                <div class="text-muted"><i class="bi bi-arrow-down-up me-1"></i>Sorted by Priority</div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead>
                        <tr>
                            <th>Patient Name</th>
                            <th>Request Type</th>
                            <th>Blood Group</th>
                            <th>Organ Needed</th>
                            <th>Priority Score</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($patients) > 0): ?>
                            <?php foreach ($patients as $p): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="bg-light rounded-circle p-2 me-3 d-flex align-items-center justify-content-center"
                                                style="width: 40px; height: 40px;">
                                                <i class="bi bi-person-fill text-secondary"></i>
                                            </div>
                                            <span class="fw-bold text-dark"><?php echo htmlspecialchars($p['name']); ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($p['request_type'] === 'blood'): ?>
                                            <span class="req-type req-blood"><i class="bi bi-droplet-fill me-1"></i>Blood</span>
                                        <?php else: ?>
                                            <span class="req-type req-organ"><i class="bi bi-lungs-fill me-1"></i>Organ</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span
                                            class="badge bg-secondary rounded-pill px-2 py-1"><?php echo htmlspecialchars($p['blood_group']); ?></span>
                                    </td>
                                    <td>
                                        <?php echo $p['organ_needed'] ? htmlspecialchars($p['organ_needed']) : '<span class="text-muted fst-italic">N/A</span>'; ?>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <span
                                                class="fw-bold me-2"><?php echo htmlspecialchars($p['priority_score']); ?></span>
                                            <div class="progress flex-grow-1" style="height: 6px;">
                                                <?php
                                                $width = min(100, $p['priority_score']);
                                                $bgClass = $p['priority_score'] > 60 ? 'bg-danger' : 'bg-primary';
                                                ?>
                                                <div class="progress-bar <?php echo $bgClass; ?>" role="progressbar"
                                                    style="width: <?php echo $width; ?>%;"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php
                                        // Handle dynamically mapping statuses to our badge classes
                                        $status = strtolower($p['status']);
                                        $badgeClass = 'badge-pending';
                                        $icon = 'bi-hourglass';
                                        $text = ucfirst($status);

                                        if ($status === 'approved') {
                                            $badgeClass = 'badge-approved';
                                            $icon = 'bi-check-circle';
                                        } elseif ($status === 'fulfilled') {
                                            $badgeClass = 'badge-fulfilled';
                                            $icon = 'bi-heart-fill';
                                        } elseif ($status === 'waiting_for_donor') {
                                            $badgeClass = 'badge-waiting';
                                            $icon = 'bi-search';
                                            $text = 'Waiting';
                                        }
                                        ?>
                                        <span class="status-badge <?php echo $badgeClass; ?>">
                                            <i class="bi <?php echo $icon; ?> me-1"></i><?php echo htmlspecialchars($text); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">No patient requests found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

    <!-- Modal Form for New Request -->
    <div class="modal fade" id="newRequestModal" tabindex="-1" aria-labelledby="newRequestLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="newRequestLabel"><i
                            class="bi bi-file-earmark-medical me-2 text-danger"></i>New Patient Request</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="patient_dashboard.php" method="POST">
                    <div class="modal-body p-4">
                        <div class="mb-3">
                            <label class="form-label fw-bold text-muted small">Full Name</label>
                            <input type="text" name="name" class="form-control" required placeholder="e.g. John Doe">
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-muted small">Age</label>
                                <input type="number" name="age" class="form-control" required min="1" max="120">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-muted small">Blood Group</label>
                                <select name="blood_group" class="form-select" required>
                                    <option value="" disabled selected>Select Group...</option>
                                    <option value="A+">A+</option>
                                    <option value="A-">A-</option>
                                    <option value="B+">B+</option>
                                    <option value="B-">B-</option>
                                    <option value="AB+">AB+</option>
                                    <option value="AB-">AB-</option>
                                    <option value="O+">O+</option>
                                    <option value="O-">O-</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold text-muted small">Request Type</label>
                            <select name="request_type" id="requestTypeSelect" class="form-select" required
                                onchange="toggleOrganNeeded()">
                                <option value="" disabled selected>Select Type...</option>
                                <option value="blood">Blood Donation</option>
                                <option value="organ">Organ Donation</option>
                            </select>
                        </div>
                        <div class="mb-3" id="organNeededDiv" style="display: none;">
                            <label class="form-label fw-bold text-muted small">Organ Needed</label>
                            <input type="text" name="organ_needed" id="organNeededInput" class="form-control"
                                placeholder="e.g. Kidney, Liver">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold text-muted small">Patient Condition</label>
                            <select name="condition" class="form-select" required>
                                <option value="normal">Normal / Routine</option>
                                <option value="urgent">Urgent</option>
                                <option value="critical">Critical</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer bg-light border-0 py-3 px-4">
                        <button type="button" class="btn btn-outline-secondary rounded-pill px-4"
                            data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="submit_request"
                            class="btn btn-request rounded-pill border-0 shadow-sm">Submit Request <i
                                class="bi bi-send ms-1"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS & Data Display Logic -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggles the visibility of the "Organ Needed" input based on Request Type dropdown
        function toggleOrganNeeded() {
            var requestType = document.getElementById('requestTypeSelect').value;
            var organDiv = document.getElementById('organNeededDiv');
            var organInput = document.getElementById('organNeededInput');

            if (requestType === 'organ') {
                organDiv.style.display = 'block';
                organInput.setAttribute('required', 'required');
            } else {
                organDiv.style.display = 'none';
                organInput.removeAttribute('required');
                organInput.value = '';
            }
        }
    </script>
</body>

</html>
<?php
$host = 'localhost';
$dbname = 'organ_blood_donation';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $message = "";

    // Handle Stock Update
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_stock'])) {
        $inventory_id = $_POST['inventory_id'];
        $action = $_POST['action']; // 'add' or 'remove'
        $amount = (int)$_POST['amount'];
        
        $stmt = $pdo->prepare("SELECT units_available FROM blood_inventory WHERE inventory_id = ?");
        $stmt->execute([$inventory_id]);
        $currentUnits = (int)$stmt->fetchColumn();
        
        if ($action === 'add') {
            $newUnits = $currentUnits + $amount;
        } else {
            $newUnits = max(0, $currentUnits - $amount);
        }
        
        $updateStmt = $pdo->prepare("UPDATE blood_inventory SET units_available = ? WHERE inventory_id = ?");
        $updateStmt->execute([$newUnits, $inventory_id]);
        
        $message = "<div class='alert alert-success alert-dismissible fade show' role='alert'>
                        <i class='bi bi-check-circle-fill me-2'></i>Inventory successfully updated!
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>";
    }

    // Handle Fulfill Action
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fulfill_request'])) {
        $patient_id = $_POST['patient_id'];
        $pdo->beginTransaction();
        try {
            $stmtFulfill = $pdo->prepare("UPDATE patients SET status = 'fulfilled' WHERE patient_id = ?");
            $stmtFulfill->execute([$patient_id]);
            
            $stmtFulfillReq = $pdo->prepare("UPDATE blood_requests SET status = 'fulfilled' WHERE patient_id = ?");
            $stmtFulfillReq->execute([$patient_id]);
            
            $pdo->commit();
            $message = "<div class='alert alert-success alert-dismissible fade show' role='alert'>
                            <i class='bi bi-heart-pulse-fill me-2'></i>Blood Request successfully fulfilled and logged!
                            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                        </div>";
        } catch (Exception $e) {
            $pdo->rollBack();
            $message = "<div class='alert alert-danger'>Error fulfilling request: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    }

    // Prepare Base Blood Groups
    $groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
    
    // Fetch Total Aggregated Blood Inventory
    $aggQuery = "SELECT blood_group, SUM(units_available) as total_units FROM blood_inventory GROUP BY blood_group";
    $aggResult = $pdo->query($aggQuery)->fetchAll(PDO::FETCH_KEY_PAIR);
    
    $totalInventory = [];
    $lowStockAlerts = [];
    
    foreach ($groups as $g) {
        $units = isset($aggResult[$g]) ? (int)$aggResult[$g] : 0;
        $totalInventory[$g] = $units;
        
        if ($units == 0) {
            $lowStockAlerts[] = "$g (Out of Stock)";
        } elseif ($units < 5) {
            $lowStockAlerts[] = "$g (Low : $units units)";
        }
    }

    // Fetch Detailed Inventory Table for Management
    $queryDetailed = "
        SELECT i.inventory_id, b.name as bank_name, i.blood_group, i.units_available 
        FROM blood_inventory i 
        JOIN blood_banks b ON i.bank_id = b.bank_id 
        ORDER BY i.blood_group, b.name";
    $detailedInventory = $pdo->query($queryDetailed)->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Approved Blood Requests
    $queryBloodRequests = "
        SELECT p.patient_id, p.name as patient_name, p.blood_group, p.priority_score, b.name as bank_name 
        FROM patients p
        JOIN blood_requests br ON p.patient_id = br.patient_id
        JOIN blood_banks b ON br.bank_id = b.bank_id
        WHERE p.request_type = 'blood' AND p.status = 'approved'
        ORDER BY p.priority_score DESC
    ";
    $approvedBloodRequests = $pdo->query($queryBloodRequests)->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database Connection Error: " . htmlspecialchars($e->getMessage()));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank Dashboard | Central Inventory</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #fce4e4;
            color: #333;
        }

        /* Red Themed Header */
        .red-header {
            background: linear-gradient(135deg, #d32f2f 0%, #ff5252 100%);
            color: white;
            padding: 3rem 0;
            border-bottom-left-radius: 40px;
            border-bottom-right-radius: 40px;
            box-shadow: 0 10px 30px rgba(211, 47, 47, 0.3);
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }

        .red-header::after {
            content: '';
            position: absolute;
            top: -20%;
            right: -5%;
            width: 30%;
            height: 150%;
            background: rgba(255,255,255,0.1);
            transform: rotate(-15deg);
            pointer-events: none;
        }

        /* Aggregated Cards Grid */
        .blood-card {
            background: white;
            border-radius: 20px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(211,47,47,0.1);
        }

        .blood-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 30px rgba(211, 47, 47, 0.15);
        }

        .drop-icon {
            font-size: 3rem;
            opacity: 0.1;
            position: absolute;
            left: -10px;
            top: 20px;
        }

        .blood-title {
            font-size: 1.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }

        /* Status Colors */
        .status-high { color: #2e7d32; }
        .status-low { color: #f57c00; }
        .status-zero { color: #c62828; }

        .border-high { border-bottom: 6px solid #2e7d32; }
        .border-low { border-bottom: 6px solid #f57c00; }
        .border-zero { border-bottom: 6px solid #c62828; }

        /* Alerts Section */
        .alerts-section {
            background: rgba(255,255,255,0.8);
            border-left: 5px solid #d32f2f;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            margin-bottom: 2rem;
        }

        /* Table Card */
        .table-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.05);
            padding: 2rem;
            margin-bottom: 3rem;
        }

        .badge-stock {
            padding: 0.5em 1em;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.85rem;
        }

        .btn-update {
            background-color: transparent;
            color: #d32f2f;
            border: 1px solid #d32f2f;
            border-radius: 50px;
            font-weight: 600;
            padding: 0.3rem 1.2rem;
            transition: all 0.2s;
        }
        .btn-update:hover {
            background-color: #d32f2f;
            color: white;
        }

        .modal-content {
            border-radius: 20px;
            border: none;
        }
    </style>
</head>
<body>

    <!-- Header Section -->
    <header class="red-header">
        <div class="container">
            <h1 class="display-5 fw-bold mb-1"><i class="bi bi-droplet-half me-2"></i>Blood Bank Dashboard</h1>
            <p class="lead mb-0 opacity-75">Global Inventory Management & Monitoring</p>
        </div>
    </header>

    <main class="container">
        
        <?php if (!empty($message)) echo $message; ?>

        <!-- Alerts Section -->
        <?php if(count($lowStockAlerts) > 0): ?>
            <div class="alerts-section d-flex align-items-center mb-4">
                <i class="bi bi-exclamation-triangle-fill text-danger fs-3 me-3"></i>
                <div>
                    <h5 class="fw-bold text-dark mb-1">Critical Stock Alerts</h5>
                    <p class="mb-0 text-muted">The following groups require immediate restocking: 
                        <strong class="text-danger"><?php echo implode(", ", $lowStockAlerts); ?></strong>
                    </p>
                </div>
            </div>
        <?php else: ?>
            <div class="alerts-section" style="border-left-color: #2e7d32;">
                <div class="d-flex align-items-center">
                    <i class="bi bi-check-circle-fill text-success fs-3 me-3"></i>
                    <div>
                        <h5 class="fw-bold text-dark mb-0">System Healthy</h5>
                        <p class="mb-0 text-muted">All aggregated blood groups are maintaining stable inventory thresholds.</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Blood Type Summary Cards -->
        <h4 class="fw-bold mb-3 text-dark"><i class="bi bi-grid-fill me-2 text-danger"></i>Aggregated System Stock</h4>
        <div class="row g-3 mb-5">
            <?php foreach($totalInventory as $group => $units): ?>
                <?php 
                    $statClass = 'status-high';
                    $borderClass = 'border-high';
                    if ($units == 0) {
                        $statClass = 'status-zero';
                        $borderClass = 'border-zero';
                    } elseif ($units < 5) {
                        $statClass = 'status-low';
                        $borderClass = 'border-low';
                    }
                ?>
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                    <div class="blood-card <?php echo $borderClass; ?>">
                        <i class="bi bi-droplet-fill drop-icon <?php echo $statClass; ?>"></i>
                        <h4 class="blood-title text-dark"><?php echo htmlspecialchars($group); ?></h4>
                        <div class="d-flex align-items-center justify-content-center">
                            <h2 class="fw-bold mb-0 me-2 <?php echo $statClass; ?>"><?php echo $units; ?></h2>
                            <span class="text-muted fw-bold">Units</span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Approved Blood Requests Action Table -->
        <div class="table-card mb-5 border-0" style="background: rgba(255, 255, 255, 0.95);">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-bold m-0 text-dark"><i class="bi bi-clock-history text-danger me-2"></i>Pending Fulfillment Queue</h4>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="text-muted text-uppercase">Patient Target</th>
                            <th class="text-muted text-uppercase">Blood Type</th>
                            <th class="text-muted text-uppercase">Dispensing Bank</th>
                            <th class="text-muted text-uppercase">Priority</th>
                            <th class="text-muted text-uppercase text-end">Operations</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($approvedBloodRequests as $req): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <i class="bi bi-person-circle fs-4 text-secondary me-2"></i>
                                        <div>
                                            <span class="fw-bold text-dark d-block"><?php echo htmlspecialchars($req['patient_name']); ?></span>
                                            <small class="text-muted">ID: #<?php echo $req['patient_id']; ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-danger rounded-pill px-3 py-2 fs-6"><?php echo htmlspecialchars($req['blood_group']); ?></span>
                                </td>
                                <td>
                                    <span class="fw-bold text-dark"><i class="bi bi-hospital me-1"></i><?php echo htmlspecialchars($req['bank_name']); ?></span>
                                </td>
                                <td>
                                    <h5 class="mb-0 fw-bold <?php echo ($req['priority_score'] > 75) ? 'text-danger' : 'text-primary'; ?>">
                                        <?php echo htmlspecialchars($req['priority_score']); ?>
                                    </h5>
                                </td>
                                <td class="text-end">
                                    <form action="bloodbank_dashboard.php" method="POST" class="m-0" onsubmit="return confirm('Confirm that blood units have been securely dispensed and surgery completed?');">
                                        <input type="hidden" name="patient_id" value="<?php echo $req['patient_id']; ?>">
                                        <button type="submit" name="fulfill_request" class="btn btn-action" style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); color: white; border-radius: 50px; font-weight: 600; padding: 0.4rem 1.2rem; border: none; box-shadow: 0 4px 10px rgba(56, 239, 125, 0.3);">
                                            <i class="bi bi-check2-all me-1"></i>Mark Fulfilled
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if(count($approvedBloodRequests) === 0): ?>
                            <tr><td colspan="5" class="text-center py-5 text-muted">No pending approved requests waiting for fulfillment.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Detailed Inventory Table -->
        <div class="table-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-bold m-0 text-dark">Detailed Facility Inventory</h4>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="text-muted text-uppercase">Facility Name</th>
                            <th class="text-muted text-uppercase">Blood Group</th>
                            <th class="text-muted text-uppercase">Units Available</th>
                            <th class="text-muted text-uppercase">Status</th>
                            <th class="text-muted text-uppercase text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($detailedInventory as $inv): ?>
                            <tr>
                                <td>
                                    <i class="bi bi-hospital me-2 text-primary"></i>
                                    <span class="fw-bold text-dark"><?php echo htmlspecialchars($inv['bank_name']); ?></span>
                                </td>
                                <td>
                                    <span class="badge bg-danger rounded-pill px-3 py-1 fs-6"><?php echo htmlspecialchars($inv['blood_group']); ?></span>
                                </td>
                                <td>
                                    <h5 class="mb-0 fw-bold"><?php echo htmlspecialchars($inv['units_available']); ?></h5>
                                </td>
                                <td>
                                    <?php 
                                        $u = $inv['units_available'];
                                        if ($u == 0) {
                                            echo '<span class="badge-stock bg-danger text-light"><i class="bi bi-x-circle me-1"></i>Out of Stock</span>';
                                        } elseif ($u < 5) {
                                            echo '<span class="badge-stock bg-warning text-dark"><i class="bi bi-exclamation-triangle me-1"></i>Low Stock</span>';
                                        } else {
                                            echo '<span class="badge-stock bg-success text-light"><i class="bi bi-check-circle me-1"></i>Available</span>';
                                        }
                                    ?>
                                </td>
                                <td class="text-end">
                                    <button class="btn btn-update" onclick="openUpdateModal(<?php echo $inv['inventory_id']; ?>, '<?php echo htmlspecialchars($inv['blood_group']); ?>', '<?php echo htmlspecialchars(addslashes($inv['bank_name'])); ?>')">
                                        <i class="bi bi-pencil-square me-1"></i>Update
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if(count($detailedInventory) == 0): ?>
                            <tr><td colspan="5" class="text-center py-4">No inventory data found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

    <!-- Update Stock Modal -->
    <div class="modal fade" id="updateStockModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-header bg-light border-0">
                    <h5 class="modal-title fw-bold text-dark" id="modalTitle">Update Stock</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="bloodbank_dashboard.php" method="POST">
                    <div class="modal-body p-4">
                        
                        <p class="mb-3 text-muted" id="modalDesc"></p>
                        
                        <input type="hidden" name="inventory_id" id="modalInventoryId">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-muted small">Action Type</label>
                            <select name="action" class="form-select" required>
                                <option value="add">Add Units (+)</option>
                                <option value="remove">Remove Units (-)</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold text-muted small">Amount</label>
                            <input type="number" name="amount" class="form-control" required min="1" max="100" placeholder="e.g. 5">
                        </div>
                    </div>
                    <div class="modal-footer border-0 bg-light p-3">
                        <button type="button" class="btn btn-light border rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_stock" class="btn btn-danger rounded-pill px-4 shadow-sm"><i class="bi bi-save me-1"></i> Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function openUpdateModal(id, bg, bank) {
            document.getElementById('modalInventoryId').value = id;
            document.getElementById('modalTitle').innerHTML = '<i class="bi bi-droplet-fill text-danger me-2"></i>' + bg + ' Inventory';
            document.getElementById('modalDesc').innerText = 'Updating stock for ' + bank + '.';
            
            var modal = new bootstrap.Modal(document.getElementById('updateStockModal'));
            modal.show();
        }
    </script>
</body>
</html>

<?php
/**
 * Script to calculate and update priority_score for all patients
 * in the Organ and Blood Donation System.
 */

// Database Configuration
$host = 'localhost';
$dbname = 'organ_blood_donation';
$username = 'root'; // Adjust to your MySQL username
$password = '';     // Adjust to your MySQL password

try {
    // Determine connection via PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);

    // Set error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 1. Fetch patient records (target a specific patient if $target_patient_id exists, else all)
    if (isset($target_patient_id)) {
        $query = "SELECT patient_id, age, `condition`, request_date FROM patients WHERE patient_id = " . (int)$target_patient_id;
    } else {
        $query = "SELECT patient_id, age, `condition`, request_date FROM patients";
    }
    $stmt = $pdo->query($query);
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Prepare update statement for efficiency
    $updateQuery = "UPDATE patients SET priority_score = :priority_score WHERE patient_id = :patient_id";
    $updateStmt = $pdo->prepare($updateQuery);

    $updatedCount = 0;
    $currentDate = new DateTime(); // Get the current date and time

    // 2. Iterate through each patient to calculate their priority score
    foreach ($patients as $patient) {
        $priorityScore = 0;

        // --- Calculate Condition Score ---
        if ($patient['condition'] === 'critical') {
            $priorityScore += 100;
        } elseif ($patient['condition'] === 'urgent') {
            $priorityScore += 70;
        } elseif ($patient['condition'] === 'normal') {
            $priorityScore += 40;
        }

        // --- Calculate Age Score ---
        if ($patient['age'] < 12 || $patient['age'] > 60) {
            $priorityScore += 30;
        } else {
            $priorityScore += 20;
        }

        // --- Calculate Waiting Time Score ---
        // Difference between current date and request_date in days × 2
        $requestDate = new DateTime($patient['request_date']);

        // Calculate the difference between today and the request date
        $interval = $currentDate->diff($requestDate);

        // Ensure we only look at days passed (if request_date is in the past)
        // If the date is the same day, $interval->days will be 0.
        // It strictly counts full 24-hour periods by default or purely day drops depending on strictness.
        // Doing $interval->days returns the absolute number of days.
        $waitingDays = $interval->days;

        $priorityScore += ($waitingDays * 2);

        // 3. Update the priority_score column in the patient table
        $updateStmt->execute([
            ':priority_score' => $priorityScore,
            ':patient_id' => $patient['patient_id']
        ]);

        $updatedCount++;
    }

    echo "<h3>Success!</h3>";
    echo "<p>Priority scores have been successfully calculated and updated for <strong>$updatedCount</strong> patients.</p>";

} catch (PDOException $e) {
    // Handle database-related errors
    echo "<h3>Database Error</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
} catch (Exception $e) {
    // Handle other general errors (e.g., DateTime parsing)
    echo "<h3>General Error</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
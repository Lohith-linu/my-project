<?php
$host = 'localhost';
$dbname = 'organ_blood_donation';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database Connection Error: " . htmlspecialchars($e->getMessage()));
}

$message = "";

// Handle POST request for accepting/rejecting requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response_id = $_POST['response_id'] ?? null;
    $patient_id = $_POST['patient_id'] ?? null;
    $action = $_POST['action'] ?? null;

    if ($response_id && $patient_id && $action) {
        $pdo->beginTransaction();
        try {
            if ($action === 'accept') {
                // Update donor_responses
                $stmtUpdateResp = $pdo->prepare("UPDATE donor_responses SET response = 'accepted' WHERE response_id = :response_id");
                $stmtUpdateResp->execute([':response_id' => $response_id]);

                // Update patient
                $stmtUpdatePatient = $pdo->prepare("UPDATE patients SET status = 'approved' WHERE patient_id = :patient_id");
                $stmtUpdatePatient->execute([':patient_id' => $patient_id]);

                $message = "<div class='alert alert-success d-flex align-items-center' role='alert'>
                                <i class='bi bi-check-circle-fill me-2'></i>
                                <div>Match successfully <strong>Accepted</strong>! Patient has been approved.</div>
                            </div>";
            } elseif ($action === 'reject') {
                // Update donor_responses
                $stmtUpdateResp = $pdo->prepare("UPDATE donor_responses SET response = 'rejected' WHERE response_id = :response_id");
                $stmtUpdateResp->execute([':response_id' => $response_id]);

                // Update patient back to pending so they can be re-matched
                $stmtUpdatePatient = $pdo->prepare("UPDATE patients SET status = 'pending' WHERE patient_id = :patient_id");
                $stmtUpdatePatient->execute([':patient_id' => $patient_id]);

                $message = "<div class='alert alert-warning d-flex align-items-center' role='alert'>
                                <i class='bi bi-x-circle-fill me-2'></i>
                                <div>Match <strong>Rejected</strong>. The patient has been returned to the pending queue and the system is actively searching for a new donor.</div>
                            </div>";
                
                // Immediately trigger matching again behind the scenes
                ob_start();
                include 'matching_system.php';
                ob_end_clean();
            }
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $message = "<div class='alert alert-danger'>Error processing request: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    }
}

// Fetch all pending donor responses
$query = "
    SELECT dr.response_id, dr.donor_id, dr.patient_id, p.organ_needed, p.blood_group 
    FROM donor_responses dr
    JOIN patients p ON dr.patient_id = p.patient_id
    WHERE dr.response = 'pending'
";
$pendingRequests = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor Dashboard | Confirm Matches</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            color: #333;
        }

        .header-bg {
            background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
            color: white;
            padding: 4rem 0 3rem 0;
            border-bottom-left-radius: 40px;
            border-bottom-right-radius: 40px;
            box-shadow: 0 10px 30px rgba(255, 65, 108, 0.3);
            margin-bottom: 3rem;
            position: relative;
            overflow: hidden;
        }

        .header-bg::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -10%;
            width: 50%;
            height: 200%;
            background: rgba(255,255,255,0.1);
            transform: rotate(30deg);
        }

        .match-card {
            background: rgba(255, 255, 255, 0.85);
            border: 1px solid rgba(255, 255, 255, 0.4);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        .match-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.12);
        }

        .badge-blood {
            background-color: #ff4b2b;
            font-size: 1.1rem;
            padding: 0.5rem 1.2rem;
            border-radius: 50px;
            color: white;
            font-weight: 600;
        }

        .badge-organ {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-size: 1.1rem;
            padding: 0.5rem 1.2rem;
            border-radius: 50px;
            color: white;
            font-weight: 600;
        }

        .action-btn {
            padding: 0.6rem 2rem;
            border-radius: 50px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .action-btn i {
            font-size: 1.2rem;
        }

        .btn-accept {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
            box-shadow: 0 5px 15px rgba(56, 239, 125, 0.4);
        }

        .btn-accept:hover {
            background: linear-gradient(135deg, #0f857b 0%, #2bd06a 100%);
            color: white;
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(56, 239, 125, 0.6);
        }

        .btn-reject {
            background: linear-gradient(135deg, #cb2d3e 0%, #ef473a 100%);
            color: white;
            box-shadow: 0 5px 15px rgba(239, 71, 58, 0.4);
        }

        .btn-reject:hover {
            background: linear-gradient(135deg, #ab2634 0%, #cf3d32 100%);
            color: white;
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(239, 71, 58, 0.6);
        }

        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 20px;
            border: 2px dashed rgba(0,0,0,0.1);
        }

        .empty-state i {
            font-size: 4rem;
            color: #a0aec0;
            margin-bottom: 1rem;
        }
        
    </style>
</head>
<body>

    <header class="header-bg text-center">
        <div class="container position-relative" style="z-index: 1;">
            <h1 class="display-4 fw-bold mb-3"><i class="bi bi-heart-pulse"></i> Donor Match Dashboard</h1>
            <p class="lead mb-0">Review pending life-saving organ requests mapped to your profile.</p>
        </div>
    </header>

    <main class="container">
        
        <!-- Success/Error Message display -->
        <?php if (!empty($message)) echo $message; ?>

        <?php if (count($pendingRequests) > 0): ?>
            <div class="row">
                <?php foreach ($pendingRequests as $req): ?>
                    <div class="col-md-6 mb-4">
                        <div class="match-card h-100 d-flex flex-column">
                            
                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <h3 class="fw-bold mb-0 text-dark">
                                    <i class="bi bi-person-badge text-muted me-2"></i>Patient #<?php echo htmlspecialchars($req['patient_id']); ?>
                                </h3>
                                <span class="badge bg-warning text-dark fs-6 rounded-pill px-3 py-2"><i class="bi bi-hourglass-split me-1"></i> Pending</span>
                            </div>

                            <div class="mb-4 details-grid">
                                <div class="d-flex align-items-center mb-3">
                                    <h5 class="mb-0 text-muted me-3" style="min-width: 120px;">Organ Needed:</h5>
                                    <span class="badge-organ">
                                        <i class="bi bi-lungs me-1"></i><?php echo htmlspecialchars($req['organ_needed']); ?>
                                    </span>
                                </div>
                                <div class="d-flex align-items-center">
                                    <h5 class="mb-0 text-muted me-3" style="min-width: 120px;">Blood Group:</h5>
                                    <span class="badge-blood">
                                        <i class="bi bi-droplet-fill me-1"></i><?php echo htmlspecialchars($req['blood_group']); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="mt-auto pt-3 border-top d-flex justify-content-end gap-3">
                                <form method="POST" action="donor_dashboard.php" class="m-0">
                                    <input type="hidden" name="response_id" value="<?php echo htmlspecialchars($req['response_id']); ?>">
                                    <input type="hidden" name="patient_id" value="<?php echo htmlspecialchars($req['patient_id']); ?>">
                                    
                                    <button type="submit" name="action" value="reject" class="btn action-btn btn-reject">
                                        <i class="bi bi-x-lg"></i> Reject Match
                                    </button>
                                </form>
                                
                                <form method="POST" action="donor_dashboard.php" class="m-0">
                                    <input type="hidden" name="response_id" value="<?php echo htmlspecialchars($req['response_id']); ?>">
                                    <input type="hidden" name="patient_id" value="<?php echo htmlspecialchars($req['patient_id']); ?>">
                                    
                                    <button type="submit" name="action" value="accept" class="btn action-btn btn-accept">
                                        <i class="bi bi-check-lg"></i> Accept Match
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <i class="bi bi-inbox"></i>
                <h3 class="fw-bold">No Pending Requests</h3>
                <p class="text-muted fs-5">There are no pending matches at this time. You've cleared the queue!</p>
            </div>
        <?php endif; ?>

    </main>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
